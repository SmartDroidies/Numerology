'use strict';

// Define the `numberQualities` module
angular.module('numberQualities', []);