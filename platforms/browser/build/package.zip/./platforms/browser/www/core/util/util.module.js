'use strict';

// Define the `core.util` module
angular.module('core.util', []);