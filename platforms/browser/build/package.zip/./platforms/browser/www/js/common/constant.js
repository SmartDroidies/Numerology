//Numerology value for Aplhabets
//Pythagorean Numerology
// A J S - 1
// B K T - 2
// C L U - 3
// D M V - 4
// E N W - 5
// F O X - 6
// G P Y - 7
// H Q Z - 8
// I R - 9

var alphabetArray = new Array();
alphabetArray['a'] = 1;
alphabetArray['b'] = 2;
alphabetArray['c'] = 3;
alphabetArray['d'] = 4;
alphabetArray['e'] = 5;
alphabetArray['f'] = 6;
alphabetArray['g'] = 7;
alphabetArray['h'] = 8;
alphabetArray['i'] = 9;
alphabetArray['j'] = 1;
alphabetArray['k'] = 2;
alphabetArray['l'] = 3;
alphabetArray['m'] = 4;
alphabetArray['n'] = 5;
alphabetArray['o'] = 6;
alphabetArray['p'] = 7;
alphabetArray['q'] = 8;
alphabetArray['r'] = 9;
alphabetArray['s'] = 1;
alphabetArray['t'] = 2;
alphabetArray['u'] = 3;
alphabetArray['v'] = 4;
alphabetArray['w'] = 5;
alphabetArray['x'] = 6;
alphabetArray['y'] = 7;
alphabetArray['z'] = 8;

//console.log("Value of W - " + alphabetArray['w']);