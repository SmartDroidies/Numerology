'use strict';

// Define the `learnings` module
angular.module('learnings', []);