'use strict';

// Define the `dashboard` module
angular.module('dashboard', []);