'use strict';

// Define the `charValues` module
angular.module('charValues', []);