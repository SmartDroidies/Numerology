'use strict';

// Define the `header` module
angular.module('header', []);